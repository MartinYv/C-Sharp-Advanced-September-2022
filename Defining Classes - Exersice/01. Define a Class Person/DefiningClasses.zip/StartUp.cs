﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person person = new Person();
            person.Name = "Maria";
            person.Age = 22;


            Person person2 = new Person("Vikroria", 23);
        }
    }
}
