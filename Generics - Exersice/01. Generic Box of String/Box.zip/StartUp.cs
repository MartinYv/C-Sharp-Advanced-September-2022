﻿using System;
using System.Collections.Generic;

namespace Box
{ 
    public class StartUp
    {
        static void Main()
        {

            List<Box<string>> list =  new List<Box<string>>();
            int linesCount = int.Parse(Console.ReadLine());

            for (int i = 0; i < linesCount; i++)
            {
                string input = Console.ReadLine();

                Box<string> box = new Box<string>(input);
                list.Add(box);
            }

            foreach (Box<string> box in list)
            {
                Console.WriteLine(box.ToString());
            }
        }
    }
}
