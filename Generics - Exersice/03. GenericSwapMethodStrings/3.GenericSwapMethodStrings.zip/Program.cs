﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _3.GenericSwapMethodStrings
{
   public class Program
    {
        static void Main(string[] args)
        {
            List<Box<string>> list = new List<Box<string>>();

            int count = int.Parse(Console.ReadLine());

            for (int i = 0; i < count; i++)
            {
                string input = Console.ReadLine();

                Box<string> box = new Box<string>(input);
                list.Add(box);

            }

            int[] indexes = Console.ReadLine().Split().Select(int.Parse).ToArray();

            int firstIndex = indexes[0];
            int secondIndex = indexes[1];

            
            
            foreach (var box in list)
            {
                box.Swap(list, firstIndex, secondIndex);
                break;
            }

            foreach (var box in list)
            {
                Console.WriteLine(box.ToString());

            }
        }
    }
}
