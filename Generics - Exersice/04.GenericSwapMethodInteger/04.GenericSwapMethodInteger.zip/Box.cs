﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.GenericSwapMethodInteger
{
    public class Box<T>
    {

        public Box(T input)
        {
            Input = input;
        }

        public T Input { get; set; }


        public override string ToString()
        {
            return $"{typeof(T)}: {Input}";
        }

        public void Swap(List<Box<T>> list,int firstIndex, int secondIndex)
        {
            var tempIndex = list[firstIndex];
            list[firstIndex] = list[secondIndex];
           list[secondIndex] = tempIndex;



        }
    }
}
